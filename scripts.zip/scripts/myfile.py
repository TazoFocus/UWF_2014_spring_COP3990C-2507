title = "The Meaning of Life"
quote="Hello World!"
