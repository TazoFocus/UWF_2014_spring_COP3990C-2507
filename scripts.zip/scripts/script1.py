# A first Python script
import sys                  # Load a library module
print(sys.platform)
print(2 ** 32)              # Raise 2 to a power
x = 'Spam!'
print(x * 8)                # String repetition
